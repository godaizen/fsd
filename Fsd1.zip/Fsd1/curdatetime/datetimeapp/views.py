from django.shortcuts import render
from django.http import HttpResponse
import datetime

# Create your views here.

def current_datetime(request):
    now=datetime.datetime.now()
    html = f"<html><body><h1>Current Date and Time:</h1><p>{now}</p></body></html>" 
    return HttpResponse(html)
    