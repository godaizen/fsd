from django.shortcuts import render
from django.http import JsonResponse
from .forms import StudentRegistrationForm

def register_student(request):
    if request.method == 'POST':
        form = StudentRegistrationForm(request.POST)
        if form.is_valid():
            # Process valid form data (e.g., save to database)
            # Return a JSON response for AJAX handling
            return JsonResponse({"success": True, "message": "Student registered successfully!"})
        else:
            # Return JSON response with form errors
            return JsonResponse({"success": False, "errors": form.errors})
    else:
        form = StudentRegistrationForm()
    return render(request, 'enrollment/register.html', {'form': form})
