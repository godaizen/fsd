from django.apps import AppConfig


class Pg1AppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pg1app'
