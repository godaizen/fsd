from django.apps import AppConfig


class YashasappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'yashasApp'
